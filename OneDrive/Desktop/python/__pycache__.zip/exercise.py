# -*- coding: utf-8 -*-
"""
Created on Thu Dec  8 10:07:05 2022

@author: tinky
"""

a = 'the quick brown fox jumps over the lazy dog'
print(a.split())
print(a.find('quick'))